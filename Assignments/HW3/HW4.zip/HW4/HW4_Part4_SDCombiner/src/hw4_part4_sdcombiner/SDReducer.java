/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part4_sdcombiner;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SortedMapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author yamini
 */
public class SDReducer extends Reducer<Text, SortedMapWritable, Text, MedianStdDevTuple>
{
    MedianStdDevTuple result = new MedianStdDevTuple();
    TreeMap<Double,Long> ratingsCount = new TreeMap<Double,Long>();
    
    public void reduce(Text key, Iterable<SortedMapWritable> values, Context context)
            throws IOException, InterruptedException
    {
        float sum = 0;
        long totalRatings = 0;
        ratingsCount.clear();
        result.setMedian(0);
        result.setStandardDeviation(0);
        
          for(SortedMapWritable val:values){
                for(Map.Entry<WritableComparable, Writable> entry:val.entrySet()){
                    double rating = ((DoubleWritable)entry.getKey()).get();
                    long count = ((LongWritable)entry.getValue()).get();
                    
                    totalRatings+=count;
                    sum+=rating*count;
                    
                    Long storedCount = ratingsCount.get(rating);
                    if(storedCount == null){
                        ratingsCount.put(rating, count);
                    }else{
                        ratingsCount.put(rating, storedCount+count);
                    }
                    
                }
            }
          
          
          long medianIndex = totalRatings/2L;
          long previousRatings = 0;
          long ratings = 0;
          double prevKey = 0;
          
          for(Entry<Double, Long> entry:ratingsCount.entrySet()){
              
              ratings = previousRatings + entry.getValue();
              
              if(previousRatings <= medianIndex && medianIndex<ratings){
                  if(totalRatings % 2 == 0 && previousRatings == medianIndex){
                      result.setMedian((entry.getKey()+prevKey)/2.0);
                      
                  }else{
                      result.setMedian(entry.getKey());
                  }
                  break;
                  
              }
              
              previousRatings = ratings;
              prevKey = entry.getKey();
          }
          
          double mean = sum/totalRatings;
          System.out.println("Mean:" + mean);
          double sumOfSquares = 0.0;
          
          for(Entry<Double, Long> entry:ratingsCount.entrySet()){
              sumOfSquares+= (entry.getKey() - mean) * (entry.getKey() - mean) * (entry.getValue());
          }
          
          result.setStandardDeviation(Math.sqrt((sumOfSquares)/(totalRatings-1)));
          context.write(key, result);
          
        
    }
    
}
