/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part4_sdcombiner;

import java.io.IOException;
import java.util.Map.Entry;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SortedMapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author yamini
 */
public class SDCombiner extends Reducer<Text, SortedMapWritable, Text, SortedMapWritable >{
    
    public void reduce(Text key, Iterable<SortedMapWritable> values, Context context)
            throws IOException, InterruptedException
    {
        SortedMapWritable sortedMap = new SortedMapWritable();
        
        for(SortedMapWritable val: values){
            for(Entry<WritableComparable, Writable> entry:val.entrySet()){
                LongWritable mapValue = (LongWritable) sortedMap.get(entry.getKey());
                if(mapValue!=null){
                    mapValue.set(mapValue.get()+((LongWritable)entry.getValue()).get());
                    
                }else{
                    sortedMap.put((DoubleWritable)entry.getKey(), new LongWritable(((LongWritable)entry.getValue()).get()));
                }
            }
            val.clear();
            
        }
        
        context.write(key, sortedMap);
        
    }
    
}
