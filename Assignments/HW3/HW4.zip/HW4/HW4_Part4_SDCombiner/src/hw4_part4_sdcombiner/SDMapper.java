/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part4_sdcombiner;

import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.SortedMapWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author yamini
 */
public class SDMapper extends Mapper<Object, Text, Text, SortedMapWritable>{
    
    public static final IntWritable ONE = new IntWritable(1);
        private DoubleWritable rating1 = new DoubleWritable();
        
        public void map(Object key, Text value, Context context)
        {
            Text movieId = new Text();
            
            try{
                String[] tokens = value.toString().split("::");
                movieId.set(tokens[1]);
                String rating = tokens[2];
                rating1.set(Double.parseDouble(rating));
                
                SortedMapWritable sortedMap = new SortedMapWritable();
                sortedMap.put(rating1, ONE);
                context.write(movieId, sortedMap);
                
             }catch(Exception e){
                e.printStackTrace();
            }
            
        }
    
}
