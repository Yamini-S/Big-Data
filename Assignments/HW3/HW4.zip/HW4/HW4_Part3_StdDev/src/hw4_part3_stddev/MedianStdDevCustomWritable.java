/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part3_stddev;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableUtils;

/**
 *
 * @author yamini
 */
public class MedianStdDevCustomWritable implements Writable{
   
    double median;
    double standardDeviation;
    
    public MedianStdDevCustomWritable(){
    
    }
    
    
    public MedianStdDevCustomWritable(double m, double std){
        this.median = m;
        this.standardDeviation = std;
        
    }

    public double getMedian() {
        return median;
    }

    public void setMedian(double median) {
        this.median = median;
    }

    public double getStandardDeviation() {
        return standardDeviation;
    }

    public void setStandardDeviation(double standardDeviation) {
        this.standardDeviation = standardDeviation;
    }
    
    

    @Override
    public void write(DataOutput d) throws IOException {
        WritableUtils.writeString(d, String.valueOf(median));
	WritableUtils.writeString(d, String.valueOf(standardDeviation));
    }

    @Override
    public void readFields(DataInput di) throws IOException {
       median = Double.parseDouble(WritableUtils.readString(di));
       standardDeviation = Double.parseDouble(WritableUtils.readString(di));
    }
    
    @Override
    public String toString(){
        return(new StringBuilder().append(String.valueOf(median)).append("\t").append(String.valueOf(standardDeviation))).toString();
    }
    
}
