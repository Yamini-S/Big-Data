/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part2_average;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableUtils;

/**
 *
 * @author yamini
 */
public class CountAvgTuple implements Writable{
    
    int count;
    double average;
    
    public CountAvgTuple(){
        
    }
    
    public CountAvgTuple(double average, int count)
    {
        this.average = average;
	this.count = count;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public double getAverage() {
        return average;
    }

    public void setAverage(double average) {
        this.average = average;
    }
    
    

    @Override
    public void write(DataOutput d) throws IOException {
        WritableUtils.writeString(d, String.valueOf(average));
	WritableUtils.writeString(d, String.valueOf(count));
    }

    @Override
    public void readFields(DataInput di) throws IOException {
       average = Double.parseDouble(WritableUtils.readString(di));
       count = Integer.parseInt(WritableUtils.readString(di));
    }
    
    @Override
    public String toString(){
        return String.valueOf(average);
    }
    
}
