/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part2_average;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

/**
 *
 * @author yamini
 */
public class AvgReducer extends Reducer<Text, CountAvgTuple, Text, CountAvgTuple>
{
    public void reduce(Text key, Iterable<CountAvgTuple> values, Context context) 
            throws IOException, InterruptedException
    {
        double sum = 0.0;
	int count = 0;
	
        for(CountAvgTuple input:values)
        {
            sum += input.getAverage() * input.getCount();
	    count += input.getCount();
        }
        
        context.write(key, new CountAvgTuple(sum/count, count));
		
	}
    
}
