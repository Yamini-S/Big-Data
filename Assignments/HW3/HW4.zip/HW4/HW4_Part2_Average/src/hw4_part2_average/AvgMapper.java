/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw4_part2_average;

import java.io.IOException;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

/**
 *
 * @author yamini
 */
public class AvgMapper extends Mapper<Object, Text, Text, CountAvgTuple>{
    
    public void map(Object key, Text value, Context context) 
            throws IOException, InterruptedException
    {
		String line = value.toString();
		String[] lines = line.split(",");		
		boolean check = true;
		Double stock_price_adj_close = 0.0;
		String stock_symbol = null;
		String year = null;
		if(lines.length == 9){
			stock_symbol = lines[1];
			year = getYear(lines[2]);
			
			try{
                            stock_price_adj_close = Double.parseDouble(lines[8]);
			}catch(NumberFormatException e){
				check = false;
			}
			
			if(check){
				context.write(new Text(stock_symbol+","+year), new CountAvgTuple(stock_price_adj_close, 1));
			}
		}
		
	}
	
	public String getYear(String date){
		String[] splits = date.split("-");
		return splits[0];
	}
    
}
